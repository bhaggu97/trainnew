package com.shad.TrainTicket.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.shad.TrainTicket.model.Registration;

public interface RegRep extends JpaRepository<Registration,String> {
	public Registration findByEmail(String em);

}
