package com.shad.TrainTicket.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;

import com.shad.TrainTicket.model.Registration;
import com.shad.TrainTicket.repository.RegRep;

public class customregisterservice implements UserDetailsService{
@Autowired
	private RegRep repo;

	@Override
	public UserDetails loadUserByUsername(String em) throws UsernameNotFoundException {
		try {
			Registration u=repo.findByEmail(em);
			if(u==null)
			{
				throw new UsernameNotFoundException("No User");
			}
			else {
				return new customregister(u);
			}
		}catch(Exception e) {
			e.printStackTrace();
		}
		
		return null;
	}
	

}
